package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.AgendaEntity
import com.example.data.model.AnnouncementEntity
import com.example.data.model.AuditLogEntity
import com.example.data.model.LetterRequestEntity
import com.example.data.model.ReportEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import com.example.util.SecurityUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        TransactionEntity::class,
        AnnouncementEntity::class,
        AgendaEntity::class,
        ReportEntity::class,
        LetterRequestEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun rtSmartDao(): RtSmartDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "rt08_smart_database.db"
                )
                    .addCallback(object : Callback() {
                        override fun onCreate(db: SupportSQLiteDatabase) {
                            super.onCreate(db)
                            // Populate database in background
                            CoroutineScope(Dispatchers.IO).launch {
                                INSTANCE?.let { database ->
                                    seedInitialData(database.rtSmartDao())
                                }
                            }
                        }
                    })
                    .build()
                INSTANCE = instance
                instance
            }
        }

        suspend fun seedInitialData(dao: RtSmartDao) {
            val now = System.currentTimeMillis()
            val oneDay = 24 * 60 * 60 * 1000L

            // 1. Initial Users - Exact 4 accounts requested by user
            val needsUserUpdate = dao.getUserCount() == 0 || dao.getUserByUsername("rehan") == null || dao.getUserByUsername("budi") == null
            if (needsUserUpdate) {
                dao.deleteAllUsers()
                val user1 = UserEntity(
                    username = "rehan",
                    passwordHash = SecurityUtils.hashPassword("rehan123"),
                    name = "Rehan Ardiyanto",
                    position = "Admin",
                    role = UserRole.ADMIN_UTAMA.name,
                    isActive = true,
                    createdAt = now - (30 * oneDay)
                )
                val user2 = UserEntity(
                    username = "budi",
                    passwordHash = SecurityUtils.hashPassword("budi123"),
                    name = "M. Budi Prasetyo",
                    position = "Ketua RT",
                    role = UserRole.KETUA_RT.name,
                    isActive = true,
                    createdAt = now - (30 * oneDay)
                )
                val user3 = UserEntity(
                    username = "ika",
                    passwordHash = SecurityUtils.hashPassword("ika123"),
                    name = "Ika",
                    position = "Bendahara",
                    role = UserRole.BENDAHARA.name,
                    isActive = true,
                    createdAt = now - (30 * oneDay)
                )
                val user4 = UserEntity(
                    username = "ahmadyani",
                    passwordHash = SecurityUtils.hashPassword("yani123"),
                    name = "Ahmad Yani",
                    position = "Sekretaris",
                    role = UserRole.SEKRETARIS.name,
                    isActive = true,
                    createdAt = now - (30 * oneDay)
                )
                dao.insertUser(user1)
                dao.insertUser(user2)
                dao.insertUser(user3)
                dao.insertUser(user4)
            }

            // 2. Initial Transactions
            if (dao.getTransactionCount() == 0) {
                dao.insertTransaction(
                    TransactionEntity(
                        date = now - (25 * oneDay),
                        title = "Saldo Awal Kas RT 08 Tahun Berjalan",
                        category = "Saldo Bawaan",
                        amount = 8500000L,
                        type = "PEMASUKAN",
                        proofNote = "Buku Kas 2025 No. 01/KAS/RT08",
                        isPublic = true,
                        createdBy = "Ika (Bendahara)"
                    )
                )
                dao.insertTransaction(
                    TransactionEntity(
                        date = now - (15 * oneDay),
                        title = "Iuran Warga Bulanan (64 KK x Rp 50.000)",
                        category = "Iuran Bulanan",
                        amount = 3200000L,
                        type = "PEMASUKAN",
                        proofNote = "Kwitansi Rekap Iuran No. 10/X/2026",
                        isPublic = true,
                        createdBy = "Ika (Bendahara)"
                    )
                )
                dao.insertTransaction(
                    TransactionEntity(
                        date = now - (12 * oneDay),
                        title = "Iuran Pengelolaan Sampah Warga",
                        category = "Uang Sampah",
                        amount = 1600000L,
                        type = "PEMASUKAN",
                        proofNote = "Kwitansi Kebersihan No. 11/X/2026",
                        isPublic = true,
                        createdBy = "Ika (Bendahara)"
                    )
                )
                dao.insertTransaction(
                    TransactionEntity(
                        date = now - (10 * oneDay),
                        title = "Pembayaran Honor Petugas Keamanan & Ronda (2 Orang)",
                        category = "Keamanan / Ronda",
                        amount = 2000000L,
                        type = "PENGELUARAN",
                        proofNote = "Tanda Terima Honor Satpam Pos Ronda",
                        isPublic = true,
                        createdBy = "Ika (Bendahara)"
                    )
                )
                dao.insertTransaction(
                    TransactionEntity(
                        date = now - (7 * oneDay),
                        title = "Pemasangan 4 Unit Lampu LED Penerangan Jl. Giring Giring 1",
                        category = "Perbaikan Sarana",
                        amount = 450000L,
                        type = "PENGELUARAN",
                        proofNote = "Struk Toko Listrik Sinar Depok #8821",
                        isPublic = true,
                        createdBy = "Ika (Bendahara)"
                    )
                )
                dao.insertTransaction(
                    TransactionEntity(
                        date = now - (4 * oneDay),
                        title = "Konsumsi & Alat Kerja Bakti Saluran Air Warga",
                        category = "Kegiatan Warga",
                        amount = 350000L,
                        type = "PENGELUARAN",
                        proofNote = "Nota Warung Berkah & Material Sukmajaya",
                        isPublic = true,
                        createdBy = "Ika (Bendahara)"
                    )
                )
                dao.insertTransaction(
                    TransactionEntity(
                        date = now - (2 * oneDay),
                        title = "Donasi Warga Peduli Fasilitas Pos Ronda",
                        category = "Dana Sosial",
                        amount = 500000L,
                        type = "PEMASUKAN",
                        proofNote = "Tanda Terima Donasi No. 04/DON/26",
                        isPublic = true,
                        createdBy = "Ika (Bendahara)"
                    )
                )
            }

            // 3. Initial Announcements
            dao.insertAnnouncement(
                AnnouncementEntity(
                    title = "Kerja Bakti Rutin & Pembersihan Saluran Air Jl. Giring Giring 1",
                    content = "Dihimbau kepada seluruh warga RT 08 / RW 10 untuk berpartisipasi dalam kerja bakti membersihkan saluran got dan dahan pohon menjelang musim hujan. Mohon membawa peralatan cangkul/sapu dari rumah masing-masing.",
                    category = "Kerja Bakti",
                    date = now - (1 * oneDay),
                    author = "Ahmad Yani (Sekretaris)",
                    isPinned = true
                )
            )
            dao.insertAnnouncement(
                AnnouncementEntity(
                    title = "Jadwal Fogging Nyamuk DBD dari Puskesmas Sukmajaya",
                    content = "Puskesmas Sukmajaya bersama Pengurus RT 08 akan melaksanakan pengasapan (fogging) nyamuk DBD pada hari Jumat pukul 09.00 WIB. Harap menutup makanan dan minuman serta mengamankan hewan peliharaan.",
                    category = "Kesehatan",
                    date = now - (3 * oneDay),
                    author = "Pengurus RT 08",
                    isPinned = false
                )
            )
            dao.insertAnnouncement(
                AnnouncementEntity(
                    title = "Pengelolaan & Pemilahan Sampah Rumah Tangga",
                    content = "Mengingat instruksi DLHK Kota Depok mengenai pengurangan sampah organik, warga dimohon memilah sampah dapur ke dalam kantong khusus. Petugas sampah RT beroperasi tiap Senin, Rabu, dan Sabtu pagi.",
                    category = "Lingkungan",
                    date = now - (6 * oneDay),
                    author = "Sie Kebersihan RT 08",
                    isPinned = false
                )
            )

            // 4. Initial Agendas
            dao.insertAgenda(
                AgendaEntity(
                    title = "Kerja Bakti Lingkungan Gotong Royong",
                    description = "Pembersihan saluran air dan perapihan tanaman di sepanjang Jl. Giring Giring 1.",
                    dateMillis = now + (2 * oneDay),
                    timeString = "07:00 - 10:30 WIB",
                    location = "Pos Ronda & Jl. Giring Giring 1",
                    coordinator = "Sie Kebersihan (Pak Joko)"
                )
            )
            dao.insertAgenda(
                AgendaEntity(
                    title = "Rapat Triwulan Pengurus & Tokoh Warga RT 08",
                    description = "Evaluasi laporan kas, keamanan lingkungan, dan persiapan pengaspalan jalan kelurahan.",
                    dateMillis = now + (5 * oneDay),
                    timeString = "19:30 - 21:30 WIB",
                    location = "Balai Warga RT 08",
                    coordinator = "M. Budi Prasetyo (Ketua RT)"
                )
            )
            dao.insertAgenda(
                AgendaEntity(
                    title = "Posyandu Balita & Posbindu Lansia Melati",
                    description = "Pemeriksaan tensi, penimbangan balita, dan pemberian vitamin oleh kader posyandu.",
                    dateMillis = now + (8 * oneDay),
                    timeString = "08:30 - 11:00 WIB",
                    location = "Rumah Bu RT (Jl. Giring Giring 1 No. 5)",
                    coordinator = "Kader Posyandu RT 08"
                )
            )

            // 5. Initial Reports
            dao.insertReport(
                ReportEntity(
                    reporterName = "Pak Dedi Setiawan",
                    reporterPhone = "081234567890",
                    category = "Lampu Jalan",
                    title = "Lampu jalan depan rumah No. 12 mati",
                    description = "Lampu tiang nomor 3 sudah padam sejak kemarin malam sehingga area jalan agak gelap.",
                    locationDetail = "Jl. Giring Giring 1 No. 12",
                    status = "Diproses",
                    responseNote = "Sudah dibelikan bohlam LED baru, akan diganti sore ini oleh petugas ronda.",
                    createdAt = now - (1 * oneDay),
                    updatedAt = now - (12 * 60 * 60 * 1000L)
                )
            )
            dao.insertReport(
                ReportEntity(
                    reporterName = "Ibu Maya",
                    reporterPhone = "081388776655",
                    category = "Saluran Air",
                    title = "Saluran air dekat portal agak tersumbat lumpur",
                    description = "Banyak endapan pasir setelah hujan kemarin, perlu dikeruk saat kerja bakti.",
                    locationDetail = "Dekat Portal Masuk Jl. Giring Giring 1",
                    status = "Menunggu",
                    responseNote = "",
                    createdAt = now - (6 * 60 * 60 * 1000L),
                    updatedAt = now - (6 * 60 * 60 * 1000L)
                )
            )
            dao.insertReport(
                ReportEntity(
                    reporterName = "Warga Blok B",
                    reporterPhone = "-",
                    category = "Sampah",
                    title = "Tumpukan dahan kering pasca pemangkasan",
                    description = "Dahan pohon sudah diikat rapi di pinggir lapangan menunggu pengangkutan truk DLHK.",
                    locationDetail = "Samping Pos Ronda RT 08",
                    status = "Selesai",
                    responseNote = "Sudah diangkut bersama oleh tim kebersihan pagi tadi.",
                    createdAt = now - (3 * oneDay),
                    updatedAt = now - (2 * oneDay)
                )
            )

            // 6. Initial Letters
            dao.insertLetterRequest(
                LetterRequestEntity(
                    residentName = "Rian Pratama",
                    nikOrKk = "3276011204950001",
                    letterType = "Pengantar SKCK",
                    purpose = "Persyaratan berkas lamaran pekerjaan di BUMN",
                    phoneNumber = "081987654321",
                    address = "Jl. Giring Giring 1 No. 8 RT 08/10",
                    status = "Selesai/Siap Ambil",
                    createdAt = now - (2 * oneDay)
                )
            )

            // 7. Initial Audit Log
            dao.insertAuditLog(
                AuditLogEntity(
                    timestamp = now - (25 * oneDay),
                    actor = "system",
                    action = "INISIALISASI_SISTEM",
                    details = "Sistem RT 08 SMART berhasil diinisialisasi untuk Jl. Giring Giring 1 Mekarjaya Depok"
                )
            )
        }
    }
}
