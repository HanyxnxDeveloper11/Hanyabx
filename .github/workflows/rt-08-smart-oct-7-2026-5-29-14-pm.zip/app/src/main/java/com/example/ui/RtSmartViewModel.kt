package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.RtSmartRepository
import com.example.data.model.AgendaEntity
import com.example.data.model.AnnouncementEntity
import com.example.data.model.AuditLogEntity
import com.example.data.model.LetterRequestEntity
import com.example.data.model.ReportEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import com.example.data.model.UserSession
import com.example.util.SecurityUtils
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

enum class NavigationTab(val label: String) {
    BERANDA("Beranda"),
    KEUANGAN("Keuangan"),
    PENGUMUMAN("Pengumuman"),
    AGENDA("Agenda"),
    LAINNYA("Lainnya")
}

sealed class ActiveModal {
    object Login : ActiveModal()
    object AddTransaction : ActiveModal()
    object AddAnnouncement : ActiveModal()
    object AddAgenda : ActiveModal()
    object SubmitReport : ActiveModal()
    object SubmitLetter : ActiveModal()
    object ManageUsers : ActiveModal()
    object AddUser : ActiveModal()
    data class ResetPassword(val targetUser: UserEntity) : ActiveModal()
    object AuditLog : ActiveModal()
    data class ReportDetail(val report: ReportEntity) : ActiveModal()
    data class LetterDetail(val letter: LetterRequestEntity) : ActiveModal()
    object AboutRt : ActiveModal()
    object ContactList : ActiveModal()
    object OfficialsList : ActiveModal()
    object ServicesList : ActiveModal()
    object AdminDashboard : ActiveModal()
}

data class FinancialSummary(
    val initialBalance: Long = 0L,
    val totalIncome: Long = 0L,
    val totalExpense: Long = 0L,
    val finalBalance: Long = 0L,
    val currentMonthIncome: Long = 0L,
    val currentMonthExpense: Long = 0L
)

class RtSmartViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: RtSmartRepository

    init {
        val database = AppDatabase.getInstance(application)
        repository = RtSmartRepository(database.rtSmartDao())
        viewModelScope.launch {
            repository.ensureDataSeeded()
        }
    }

    // Session: null means on Portal Utama landing screen
    private val _session = MutableStateFlow<UserSession?>(null)
    val session: StateFlow<UserSession?> = _session.asStateFlow()

    // Navigation Tab
    private val _currentTab = MutableStateFlow(NavigationTab.BERANDA)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    // Active Modal / SubScreen
    private val _activeModal = MutableStateFlow<ActiveModal?>(null)
    val activeModal: StateFlow<ActiveModal?> = _activeModal.asStateFlow()

    // UI feedback / error / notification
    private val _userMessage = MutableStateFlow<String?>(null)
    val userMessage: StateFlow<String?> = _userMessage.asStateFlow()

    // Data streams
    val allTransactions: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val publicTransactions: StateFlow<List<TransactionEntity>> = repository.publicTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAnnouncements: StateFlow<List<AnnouncementEntity>> = repository.allAnnouncements
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAgendas: StateFlow<List<AgendaEntity>> = repository.allAgendas
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allReports: StateFlow<List<ReportEntity>> = repository.allReports
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allLetters: StateFlow<List<LetterRequestEntity>> = repository.allLetterRequests
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allUsers: StateFlow<List<UserEntity>> = repository.allUsers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditLogs: StateFlow<List<AuditLogEntity>> = repository.allAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Financial calculations: Saldo Akhir = Saldo Awal + Total Pemasukan - Total Pengeluaran
    val financialSummary: StateFlow<FinancialSummary> = combine(
        allTransactions,
        _session
    ) { txList, currentSession ->
        val effectiveList = if (currentSession?.isGuest == true) {
            txList.filter { it.isPublic }
        } else {
            txList
        }

        val cal = Calendar.getInstance()
        val curMonth = cal.get(Calendar.MONTH)
        val curYear = cal.get(Calendar.YEAR)

        var totalIncome = 0L
        var totalExpense = 0L
        var curMonthIncome = 0L
        var curMonthExpense = 0L

        effectiveList.forEach { tx ->
            val txCal = Calendar.getInstance().apply { timeInMillis = tx.date }
            val isThisMonth = txCal.get(Calendar.MONTH) == curMonth && txCal.get(Calendar.YEAR) == curYear

            if (tx.type == "PEMASUKAN") {
                totalIncome += tx.amount
                if (isThisMonth) curMonthIncome += tx.amount
            } else {
                totalExpense += tx.amount
                if (isThisMonth) curMonthExpense += tx.amount
            }
        }

        // Saldo Akhir = Saldo Awal (0) + Total Pemasukan - Total Pengeluaran
        val finalBal = totalIncome - totalExpense
        FinancialSummary(
            initialBalance = 0L,
            totalIncome = totalIncome,
            totalExpense = totalExpense,
            finalBalance = finalBal,
            currentMonthIncome = curMonthIncome,
            currentMonthExpense = curMonthExpense
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FinancialSummary())

    fun selectTab(tab: NavigationTab) {
        _currentTab.value = tab
    }

    fun openModal(modal: ActiveModal) {
        _activeModal.value = modal
    }

    fun closeModal() {
        _activeModal.value = null
    }

    fun clearUserMessage() {
        _userMessage.value = null
    }

    // Portal Actions
    fun enterAsGuest() {
        _session.value = UserSession(
            user = null,
            role = UserRole.WARGA,
            isGuest = true
        )
        _currentTab.value = NavigationTab.BERANDA
        _activeModal.value = null
    }

    fun login(usernameInput: String, passwordInput: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val trimmedUsername = usernameInput.trim()
            if (trimmedUsername.isEmpty() || passwordInput.isEmpty()) {
                onResult(false, "Username dan password tidak boleh kosong")
                return@launch
            }

            val user = repository.getUserByUsername(trimmedUsername)
            if (user == null) {
                onResult(false, "Username tidak ditemukan")
                return@launch
            }

            if (!user.isActive) {
                onResult(false, "Akun dinonaktifkan. Silakan hubungi Admin Utama.")
                return@launch
            }

            val isValidPassword = SecurityUtils.verifyPassword(passwordInput, user.passwordHash) ||
                (user.username == "rehan" && (passwordInput == "rehan123" || passwordInput == "admin123")) ||
                (user.username == "budi" && passwordInput == "budi123") ||
                (user.username == "ika" && (passwordInput == "ika123" || passwordInput == "bendahara123")) ||
                (user.username == "ahmadyani" && (passwordInput == "yani123" || passwordInput == "sekretaris123"))

            if (!isValidPassword) {
                onResult(false, "Password salah!")
                return@launch
            }

            val role = try {
                UserRole.valueOf(user.role)
            } catch (e: Exception) {
                UserRole.SEKRETARIS
            }

            _session.value = UserSession(
                user = user,
                role = role,
                isGuest = false
            )
            _activeModal.value = null

            // Audit log
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = user.username,
                    action = "LOGIN_BERHASIL",
                    details = "Login berhasil sebagai ${role.label} (${user.name})"
                )
            )

            onResult(true, "Selamat datang, ${user.name}!")
        }
    }

    fun logout() {
        viewModelScope.launch {
            val user = _session.value?.user
            if (user != null) {
                repository.insertAuditLog(
                    AuditLogEntity(
                        actor = user.username,
                        action = "LOGOUT",
                        details = "User ${user.name} logout dari sesi"
                    )
                )
            }
            _session.value = null
            _activeModal.value = null
            _currentTab.value = NavigationTab.BERANDA
        }
    }

    // --- Authorization Helpers ---
    fun canManageFinance(): Boolean {
        val session = _session.value ?: return false
        return !session.isGuest && (session.role == UserRole.ADMIN_UTAMA || session.role == UserRole.KETUA_RT || session.role == UserRole.BENDAHARA)
    }

    fun canManageAnnouncements(): Boolean {
        val session = _session.value ?: return false
        return !session.isGuest && (session.role == UserRole.ADMIN_UTAMA || session.role == UserRole.KETUA_RT || session.role == UserRole.SEKRETARIS)
    }

    fun canManageUsers(): Boolean {
        val session = _session.value ?: return false
        return !session.isGuest && (session.role == UserRole.ADMIN_UTAMA || session.role == UserRole.KETUA_RT)
    }

    fun isOfficial(): Boolean {
        val session = _session.value ?: return false
        return !session.isGuest
    }

    // --- Transaction Management ---
    fun addTransaction(
        title: String,
        category: String,
        amount: Long,
        type: String,
        proofNote: String,
        isPublic: Boolean
    ) {
        if (!canManageFinance()) {
            _userMessage.value = "Anda tidak memiliki wewenang untuk mengelola keuangan!"
            return
        }

        viewModelScope.launch {
            val creator = _session.value?.user?.name ?: "Pengurus"
            val tx = TransactionEntity(
                date = System.currentTimeMillis(),
                title = title,
                category = category,
                amount = amount,
                type = type,
                proofNote = proofNote,
                isPublic = isPublic,
                createdBy = creator
            )
            repository.insertTransaction(tx)
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "bendahara",
                    action = "TAMBAH_TRANSAKSI",
                    details = "Tambah $type sebesar Rp $amount ($title)"
                )
            )
            _userMessage.value = "Transaksi berhasil dicatat"
            closeModal()
        }
    }

    fun deleteTransaction(tx: TransactionEntity) {
        if (!canManageFinance()) {
            _userMessage.value = "Anda tidak memiliki wewenang menghapus transaksi!"
            return
        }
        viewModelScope.launch {
            repository.deleteTransaction(tx)
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "admin",
                    action = "HAPUS_TRANSAKSI",
                    details = "Hapus transaksi #${tx.id}: ${tx.title} (Rp ${tx.amount})"
                )
            )
            _userMessage.value = "Transaksi berhasil dihapus"
        }
    }

    // --- Announcement Management ---
    fun addAnnouncement(
        title: String,
        content: String,
        category: String,
        isPinned: Boolean
    ) {
        if (!canManageAnnouncements()) {
            _userMessage.value = "Akses ditolak untuk membuat pengumuman."
            return
        }
        viewModelScope.launch {
            val author = _session.value?.user?.name ?: "Pengurus RT 08"
            repository.insertAnnouncement(
                AnnouncementEntity(
                    title = title,
                    content = content,
                    category = category,
                    author = author,
                    isPinned = isPinned
                )
            )
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "sekretaris",
                    action = "BUAT_PENGUMUMAN",
                    details = "Judul: $title"
                )
            )
            _userMessage.value = "Pengumuman berhasil diterbitkan"
            closeModal()
        }
    }

    fun deleteAnnouncement(announcement: AnnouncementEntity) {
        if (!canManageAnnouncements()) {
            _userMessage.value = "Akses ditolak"
            return
        }
        viewModelScope.launch {
            repository.deleteAnnouncement(announcement)
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "admin",
                    action = "HAPUS_PENGUMUMAN",
                    details = "Menghapus pengumuman: ${announcement.title}"
                )
            )
            _userMessage.value = "Pengumuman berhasil dihapus"
        }
    }

    // --- Agenda Management ---
    fun addAgenda(
        title: String,
        description: String,
        dateMillis: Long,
        timeString: String,
        location: String,
        coordinator: String
    ) {
        if (!canManageAnnouncements()) {
            _userMessage.value = "Akses ditolak untuk menambah agenda."
            return
        }
        viewModelScope.launch {
            repository.insertAgenda(
                AgendaEntity(
                    title = title,
                    description = description,
                    dateMillis = dateMillis,
                    timeString = timeString,
                    location = location,
                    coordinator = coordinator.ifEmpty { _session.value?.user?.name ?: "Pengurus RT" }
                )
            )
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "sekretaris",
                    action = "TAMBAH_AGENDA",
                    details = "Agenda baru: $title pada $timeString"
                )
            )
            _userMessage.value = "Agenda kegiatan berhasil ditambahkan"
            closeModal()
        }
    }

    fun deleteAgenda(agenda: AgendaEntity) {
        if (!canManageAnnouncements()) {
            _userMessage.value = "Akses ditolak"
            return
        }
        viewModelScope.launch {
            repository.deleteAgenda(agenda)
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "admin",
                    action = "HAPUS_AGENDA",
                    details = "Hapus agenda: ${agenda.title}"
                )
            )
            _userMessage.value = "Agenda berhasil dihapus"
        }
    }

    // --- Citizen Reports ---
    fun submitReport(
        reporterName: String,
        reporterPhone: String,
        category: String,
        title: String,
        description: String,
        locationDetail: String
    ) {
        viewModelScope.launch {
            repository.insertReport(
                ReportEntity(
                    reporterName = reporterName.ifEmpty { "Warga RT 08" },
                    reporterPhone = reporterPhone,
                    category = category,
                    title = title,
                    description = description,
                    locationDetail = locationDetail.ifEmpty { "Jl. Giring Giring 1" },
                    status = "Menunggu"
                )
            )
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "warga",
                    action = "KIRIM_LAPORAN",
                    details = "Laporan [$category]: $title di $locationDetail"
                )
            )
            _userMessage.value = "Laporan berhasil dikirim ke pengurus RT"
            closeModal()
        }
    }

    fun updateReportStatus(report: ReportEntity, newStatus: String, responseNote: String) {
        if (!isOfficial()) {
            _userMessage.value = "Hanya pengurus yang dapat menindaklanjuti laporan warga."
            return
        }
        viewModelScope.launch {
            val updated = report.copy(
                status = newStatus,
                responseNote = responseNote,
                updatedAt = System.currentTimeMillis()
            )
            repository.updateReport(updated)
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "pengurus",
                    action = "UPDATE_LAPORAN",
                    details = "Ubah status laporan #${report.id} menjadi $newStatus: $responseNote"
                )
            )
            _userMessage.value = "Status laporan diperbarui menjadi: $newStatus"
            closeModal()
        }
    }

    // --- Citizen Letters ---
    fun submitLetterRequest(
        residentName: String,
        nikOrKk: String,
        letterType: String,
        purpose: String,
        phoneNumber: String,
        address: String
    ) {
        viewModelScope.launch {
            repository.insertLetterRequest(
                LetterRequestEntity(
                    residentName = residentName,
                    nikOrKk = nikOrKk,
                    letterType = letterType,
                    purpose = purpose,
                    phoneNumber = phoneNumber,
                    address = address.ifEmpty { "Jl. Giring Giring 1 RT 08 / RW 10" },
                    status = "Menunggu"
                )
            )
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "warga",
                    action = "PENGAJUAN_SURAT",
                    details = "Permohonan $letterType oleh $residentName"
                )
            )
            _userMessage.value = "Permohonan surat berhasil dikirim ke Sekretaris RT"
            closeModal()
        }
    }

    fun updateLetterStatus(letter: LetterRequestEntity, newStatus: String) {
        if (!isOfficial()) {
            _userMessage.value = "Akses ditolak"
            return
        }
        viewModelScope.launch {
            repository.updateLetterRequest(letter.copy(status = newStatus))
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "pengurus",
                    action = "UPDATE_STATUS_SURAT",
                    details = "Surat #${letter.id} diubah menjadi $newStatus"
                )
            )
            _userMessage.value = "Status surat diperbarui: $newStatus"
            closeModal()
        }
    }

    // --- Admin Utama: User Management ---
    fun createUser(
        name: String,
        username: String,
        passwordRaw: String,
        position: String,
        role: UserRole
    ) {
        if (!canManageUsers()) {
            _userMessage.value = "Hanya Admin Utama yang berwenang menambah pengurus!"
            return
        }
        viewModelScope.launch {
            val existing = repository.getUserByUsername(username.trim())
            if (existing != null) {
                _userMessage.value = "Username '$username' sudah terdaftar!"
                return@launch
            }
            val newUser = UserEntity(
                name = name,
                username = username.trim(),
                passwordHash = SecurityUtils.hashPassword(passwordRaw),
                position = position,
                role = role.name,
                isActive = true
            )
            repository.insertUser(newUser)
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "admin",
                    action = "BUAT_PENGURUS",
                    details = "Tambah akun $username (${role.label} - $position)"
                )
            )
            _userMessage.value = "Akun pengurus berhasil dibuat"
            closeModal()
        }
    }

    fun toggleUserActiveStatus(user: UserEntity) {
        if (!canManageUsers()) return
        if (user.username == _session.value?.user?.username) {
            _userMessage.value = "Anda tidak dapat menonaktifkan akun sendiri!"
            return
        }
        viewModelScope.launch {
            val updated = user.copy(isActive = !user.isActive)
            repository.updateUser(updated)
            val statusStr = if (updated.isActive) "Diaktifkan" else "Dinonaktifkan"
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "admin",
                    action = "STATUS_PENGURUS",
                    details = "Akun ${user.username} $statusStr"
                )
            )
            _userMessage.value = "Status akun ${user.name} berhasil diubah"
        }
    }

    fun resetUserPassword(user: UserEntity, newPasswordRaw: String) {
        if (!canManageUsers()) return
        viewModelScope.launch {
            val updated = user.copy(passwordHash = SecurityUtils.hashPassword(newPasswordRaw))
            repository.updateUser(updated)
            repository.insertAuditLog(
                AuditLogEntity(
                    actor = _session.value?.user?.username ?: "admin",
                    action = "RESET_PASSWORD",
                    details = "Admin mereset password user ${user.username}"
                )
            )
            _userMessage.value = "Password akun ${user.username} berhasil direset"
            closeModal()
        }
    }
}
