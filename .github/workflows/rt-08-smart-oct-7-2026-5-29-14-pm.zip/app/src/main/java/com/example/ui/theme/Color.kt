package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary Civic Green
val CivicGreenPrimary = Color(0xFF1B5E20)
val CivicGreenOnPrimary = Color(0xFFFFFFFF)
val CivicGreenContainer = Color(0xFFD4EDDA)
val CivicGreenOnContainer = Color(0xFF0F5132)

// Secondary Teal / Forest
val ForestTealSecondary = Color(0xFF198754)
val ForestTealContainer = Color(0xFFE8F5E9)
val ForestTealOnContainer = Color(0xFF145A32)

// Tertiary Warm Gold / Amber (Community warmth)
val WarmGoldTertiary = Color(0xFFD97706)
val WarmGoldContainer = Color(0xFFFEF3C7)
val WarmGoldOnContainer = Color(0xFF78350F)

// Background & Neutral Surfaces
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F2)
val BackgroundLight = Color(0xFFF7FAF8)
val OutlineLight = Color(0xFFCBD5E1)
val OnSurfaceLight = Color(0xFF191C1B)
val OnSurfaceVariantLight = Color(0xFF3F4945)

// Status Colors
val IncomeGreen = Color(0xFF16A34A)
val ExpenseRed = Color(0xFFDC2626)
val PendingOrange = Color(0xFFEA580C)
val ProcessBlue = Color(0xFF2563EB)
val CompletedGreen = Color(0xFF15803D)
