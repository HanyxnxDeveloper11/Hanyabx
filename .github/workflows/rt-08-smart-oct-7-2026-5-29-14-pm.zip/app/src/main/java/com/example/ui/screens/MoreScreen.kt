package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserRole
import com.example.data.model.UserSession
import com.example.ui.ActiveModal
import com.example.ui.theme.CivicGreenPrimary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ForestTealSecondary
import com.example.ui.theme.WarmGoldTertiary

@Composable
fun MoreScreen(
    session: UserSession?,
    onOpenModal: (ActiveModal) -> Unit,
    onLogout: () -> Unit,
    onSwitchToLogin: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "Menu & Layanan Lainnya",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "RT 08 / RW 10 Jl. Giring Giring 1 Mekarjaya",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section Pengurus / Admin (if authorized or guest)
        item {
            if (session?.user != null) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CivicGreenPrimary.copy(alpha = 0.08f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = CivicGreenPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Panel Pengurus & Administrasi",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = CivicGreenPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        MoreMenuItem(
                            title = "Dashboard Pengurus",
                            subtitle = "Statistik kas, laporan, agenda & jalan pintas",
                            icon = Icons.Default.AdminPanelSettings,
                            iconColor = CivicGreenPrimary,
                            onClick = { onOpenModal(ActiveModal.AdminDashboard) }
                        )

                        if (session.role == UserRole.ADMIN_UTAMA || session.role == UserRole.KETUA_RT) {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = Color.LightGray.copy(alpha = 0.4f))

                            MoreMenuItem(
                                title = "Kelola Akun Pengurus",
                                subtitle = "Buat, reset password, dan nonaktifkan akun pengurus",
                                icon = Icons.Default.ManageAccounts,
                                iconColor = Color(0xFF2563EB),
                                onClick = { onOpenModal(ActiveModal.ManageUsers) }
                            )

                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = Color.LightGray.copy(alpha = 0.4f))

                            MoreMenuItem(
                                title = "Audit Log Aktivitas",
                                subtitle = "Rekam jejak login & perubahan data kas/laporan",
                                icon = Icons.Default.History,
                                iconColor = WarmGoldTertiary,
                                onClick = { onOpenModal(ActiveModal.AuditLog) }
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            } else {
                // If Warga guest, show option to login as admin
                Card(
                    onClick = onSwitchToLogin,
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = CivicGreenPrimary.copy(alpha = 0.12f),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = CivicGreenPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Login Pengurus RT",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Beralih dari mode warga ke akun pengurus/admin",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ArrowForwardIos,
                            contentDescription = null,
                            tint = Color.Gray,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        // General RT Services Section
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Informasi & Layanan Warga",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    MoreMenuItem(
                        title = "Layanan Surat Pengantar RT",
                        subtitle = "Pengantar KTP/KK, SKCK, Domisili, dan syarat berkas",
                        icon = Icons.Default.Description,
                        iconColor = ForestTealSecondary,
                        onClick = { onOpenModal(ActiveModal.ServicesList) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = Color.LightGray.copy(alpha = 0.4f))

                    MoreMenuItem(
                        title = "Lapor / Pengaduan Lingkungan",
                        subtitle = "Kirim aduan sampah, lampu mati, saluran got, dan keamanan",
                        icon = Icons.Default.ReportProblem,
                        iconColor = ExpenseRed,
                        onClick = { onOpenModal(ActiveModal.SubmitReport) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = Color.LightGray.copy(alpha = 0.4f))

                    MoreMenuItem(
                        title = "Kontak Penting & Darurat",
                        subtitle = "Pos ronda, Puskesmas, Damkar, Polsek, Bhabinkamtibmas",
                        icon = Icons.Default.Phone,
                        iconColor = Color(0xFF059669),
                        onClick = { onOpenModal(ActiveModal.ContactList) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = Color.LightGray.copy(alpha = 0.4f))

                    MoreMenuItem(
                        title = "Struktur Pengurus RT 08",
                        subtitle = "Susunan pengurus RT 08 / RW 10 Jl. Giring Giring 1",
                        icon = Icons.Default.Groups,
                        iconColor = Color(0xFF4F46E5),
                        onClick = { onOpenModal(ActiveModal.OfficialsList) }
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = Color.LightGray.copy(alpha = 0.4f))

                    MoreMenuItem(
                        title = "Tentang RT 08 SMART",
                        subtitle = "Profil lingkungan, wilayah, dan visi misi gotong royong",
                        icon = Icons.Default.Info,
                        iconColor = Color(0xFF7C3AED),
                        onClick = { onOpenModal(ActiveModal.AboutRt) }
                    )
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
        }

        // Section Logout / Ganti Mode
        item {
            Card(
                onClick = onLogout,
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_logout_more")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Logout,
                        contentDescription = "Keluar / Ganti Mode",
                        tint = ExpenseRed,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (session?.isGuest == true) "Keluar ke Portal Utama" else "Logout Akun Pengurus",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = ExpenseRed
                        )
                        Text(
                            text = "Kembali ke layar pemilihan portal",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
private fun MoreMenuItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = iconColor.copy(alpha = 0.12f),
            modifier = Modifier.size(40.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = iconColor,
                    modifier = Modifier.size(22.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Icon(
            imageVector = Icons.Default.ArrowForwardIos,
            contentDescription = null,
            tint = Color.LightGray,
            modifier = Modifier.size(14.dp)
        )
    }
}
