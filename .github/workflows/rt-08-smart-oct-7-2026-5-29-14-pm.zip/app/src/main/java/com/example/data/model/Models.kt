package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class UserRole(val label: String) {
    ADMIN_UTAMA("Admin"),
    KETUA_RT("Ketua RT"),
    BENDAHARA("Bendahara"),
    SEKRETARIS("Sekretaris"),
    WARGA("Warga (View Only)")
}

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val passwordHash: String,
    val name: String,
    val position: String, // e.g. "Ketua RT 08", "Bendahara RT 08"
    val role: String, // UserRole name
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long,
    val title: String,
    val category: String, // "Iuran Bulanan", "Uang Sampah", "Keamanan / Ronda", "Perbaikan Sarana", "Dana Sosial", "Lainnya"
    val amount: Long,
    val type: String, // "PEMASUKAN" or "PENGELUARAN"
    val proofNote: String = "", // No kwitansi / Bukti / Keterangan
    val isPublic: Boolean = true, // Warga view-only sees isPublic == true
    val createdBy: String = "Admin"
)

@Entity(tableName = "announcements")
data class AnnouncementEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val content: String,
    val category: String, // "Penting", "Kerja Bakti", "Keamanan", "Posyandu", "Umum"
    val date: Long = System.currentTimeMillis(),
    val author: String = "Pengurus RT 08",
    val isPinned: Boolean = false
)

@Entity(tableName = "agendas")
data class AgendaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String,
    val dateMillis: Long,
    val timeString: String, // e.g. "08:00 - 11:30 WIB"
    val location: String, // e.g. "Balai Warga RT 08"
    val coordinator: String = "Pengurus RT"
)

@Entity(tableName = "reports")
data class ReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reporterName: String,
    val reporterPhone: String = "",
    val category: String, // "Sampah", "Lampu Jalan", "Keamanan", "Jalan", "Saluran Air", "Fasilitas Umum", "Lingkungan Lainnya"
    val title: String,
    val description: String,
    val locationDetail: String, // e.g. "Jl. Giring Giring 1 No. 12"
    val status: String = "Menunggu", // "Menunggu", "Diproses", "Selesai"
    val responseNote: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "letter_requests")
data class LetterRequestEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val residentName: String,
    val nikOrKk: String,
    val letterType: String, // "Pengantar KTP/KK", "Keterangan Domisili", "Pengantar SKCK", "Keterangan Usaha", "Keterangan Belum Menikah"
    val purpose: String,
    val phoneNumber: String,
    val address: String = "Jl. Giring Giring 1 RT 08 / RW 10",
    val status: String = "Menunggu", // "Menunggu", "Diproses", "Selesai/Siap Ambil", "Ditolak"
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val actor: String,
    val action: String, // "LOGIN", "BUAT_TRANSAKSI", "UPDATE_LAPORAN", "TAMBAH_PENGURUS", "RESET_PASSWORD", dll
    val details: String
)

data class UserSession(
    val user: UserEntity?,
    val role: UserRole,
    val isGuest: Boolean
)
