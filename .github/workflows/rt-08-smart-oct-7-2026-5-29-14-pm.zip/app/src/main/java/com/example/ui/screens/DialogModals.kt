package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.LetterRequestEntity
import com.example.data.model.ReportEntity
import com.example.data.model.UserEntity
import com.example.data.model.UserRole
import com.example.ui.components.CategoryChip
import com.example.ui.components.StatusBadge
import com.example.ui.theme.CivicGreenPrimary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.ForestTealSecondary
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.WarmGoldTertiary
import com.example.util.Formatters

// 1. LOGIN DIALOG
@Composable
fun LoginDialog(
    onDismiss: () -> Unit,
    onLoginSubmit: (String, String) -> Unit,
    errorMessage: String? = null
) {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(22.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Login Pengurus RT",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Masukkan kredensial akun pengurus RT 08.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it },
                    label = { Text("Username") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_username_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    trailingIcon = {
                        IconButton(onClick = { passwordVisible = !passwordVisible }) {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = null
                            )
                        }
                    },
                    visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_password_input")
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage,
                        color = ExpenseRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { onLoginSubmit(username, password) },
                    colors = ButtonDefaults.buttonColors(containerColor = CivicGreenPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("login_submit_button")
                ) {
                    Text("Masuk Sebagai Pengurus", fontSize = 14.sp)
                }
            }
        }
    }
}

// 2. ADD TRANSACTION DIALOG
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionDialog(
    initialType: String = "PEMASUKAN",
    onDismiss: () -> Unit,
    onSubmit: (title: String, category: String, amount: Long, type: String, proofNote: String, isPublic: Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amountText by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(initialType) }
    var proofNote by remember { mutableStateOf("") }
    var isPublic by remember { mutableStateOf(true) }

    val categories = if (type == "PEMASUKAN") {
        listOf("Iuran Bulanan", "Uang Sampah", "Dana Sosial & Donasi", "Dana Kas RT", "Sumbangan Warga", "Lainnya")
    } else {
        listOf("Keamanan / Ronda", "Perbaikan Sarana", "Penerangan Jalan", "Kebersihan & Got", "Konsumsi Kegiatan", "Operasional RT", "Lainnya")
    }
    var selectedCategory by remember { mutableStateOf(categories.first()) }
    var expandedCategory by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Catat Transaksi Keuangan",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))

                // Radio Type
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            type = "PEMASUKAN"
                            selectedCategory = "Iuran Bulanan"
                        }
                    ) {
                        RadioButton(
                            selected = type == "PEMASUKAN",
                            onClick = {
                                type = "PEMASUKAN"
                                selectedCategory = "Iuran Bulanan"
                            }
                        )
                        Text("Pemasukan (+)", color = IncomeGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            type = "PENGELUARAN"
                            selectedCategory = "Perbaikan Sarana"
                        }
                    ) {
                        RadioButton(
                            selected = type == "PENGELUARAN",
                            onClick = {
                                type = "PENGELUARAN"
                                selectedCategory = "Perbaikan Sarana"
                            }
                        )
                        Text("Pengeluaran (-)", color = ExpenseRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Keterangan Transaksi") },
                    placeholder = { Text("Contoh: Iuran Kas Warga Blok A") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_tx_title")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = amountText,
                    onValueChange = { if (it.all { char -> char.isDigit() }) amountText = it },
                    label = { Text("Nominal (Rp)") },
                    placeholder = { Text("Contoh: 150000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_tx_amount")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Category selector
                ExposedDropdownMenuBox(
                    expanded = expandedCategory,
                    onExpandedChange = { expandedCategory = !expandedCategory }
                ) {
                    OutlinedTextField(
                        value = selectedCategory,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Kategori") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCategory) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedCategory,
                        onDismissRequest = { expandedCategory = false }
                    ) {
                        categories.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat) },
                                onClick = {
                                    selectedCategory = cat
                                    expandedCategory = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = proofNote,
                    onValueChange = { proofNote = it },
                    label = { Text("Bukti / No. Kwitansi / Nota") },
                    placeholder = { Text("Contoh: Kwitansi No. 12/X/2026") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isPublic, onCheckedChange = { isPublic = it })
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Tampilkan transparan ke warga (Publik)", fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Batal") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            val amt = amountText.toLongOrNull() ?: 0L
                            if (title.isNotEmpty() && amt > 0) {
                                onSubmit(title, selectedCategory, amt, type, proofNote, isPublic)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CivicGreenPrimary),
                        modifier = Modifier.testTag("btn_submit_transaction")
                    ) {
                        Text("Simpan Transaksi")
                    }
                }
            }
        }
    }
}

// 3. ADD ANNOUNCEMENT DIALOG
@Composable
fun AddAnnouncementDialog(
    onDismiss: () -> Unit,
    onSubmit: (title: String, content: String, category: String, isPinned: Boolean) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Umum") }
    var isPinned by remember { mutableStateOf(false) }

    val categories = listOf("Umum", "Kerja Bakti", "Keamanan", "Kesehatan", "Lingkungan")

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Buat Pengumuman Baru",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Judul Pengumuman") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_announcement_title")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Isi Pengumuman") },
                    minLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_announcement_content")
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("Kategori:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    categories.take(3).forEach { cat ->
                        Surface(
                            onClick = { category = cat },
                            color = if (category == cat) CivicGreenPrimary else MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = cat,
                                color = if (category == cat) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isPinned, onCheckedChange = { isPinned = it })
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Sematkan sebagai pengumuman penting (Pin)", fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Batal") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isNotEmpty() && content.isNotEmpty()) {
                                onSubmit(title, content, category, isPinned)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CivicGreenPrimary),
                        modifier = Modifier.testTag("btn_submit_announcement")
                    ) {
                        Text("Terbitkan")
                    }
                }
            }
        }
    }
}

// 4. ADD AGENDA DIALOG
@Composable
fun AddAgendaDialog(
    onDismiss: () -> Unit,
    onSubmit: (title: String, description: String, dateMillis: Long, timeString: String, location: String, coordinator: String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var timeString by remember { mutableStateOf("08:00 - 11:00 WIB") }
    var location by remember { mutableStateOf("Balai Warga RT 08") }
    var coordinator by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Tambah Agenda Kegiatan",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Nama Kegiatan") },
                    placeholder = { Text("Contoh: Kerja Bakti Gotong Royong") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = timeString,
                    onValueChange = { timeString = it },
                    label = { Text("Waktu Pelaksanaan") },
                    placeholder = { Text("Contoh: Minggu, 07:30 - 10:00 WIB") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = location,
                    onValueChange = { location = it },
                    label = { Text("Lokasi Tempat") },
                    placeholder = { Text("Contoh: Lapangan / Jl. Giring Giring 1") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = coordinator,
                    onValueChange = { coordinator = it },
                    label = { Text("Penanggung Jawab (PJ)") },
                    placeholder = { Text("Contoh: Pak Joko (Sie Kebersihan)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Keterangan Tambahan") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Batal") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (title.isNotEmpty()) {
                                onSubmit(
                                    title,
                                    description,
                                    System.currentTimeMillis() + (2 * 24 * 60 * 60 * 1000L),
                                    timeString,
                                    location,
                                    coordinator
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CivicGreenPrimary)
                    ) {
                        Text("Simpan Agenda")
                    }
                }
            }
        }
    }
}

// 5. SUBMIT CITIZEN REPORT DIALOG
@Composable
fun SubmitReportDialog(
    onDismiss: () -> Unit,
    onSubmit: (name: String, phone: String, category: String, title: String, desc: String, location: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Sampah") }
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var locationDetail by remember { mutableStateOf("") }

    val categories = listOf(
        "Sampah",
        "Lampu Jalan",
        "Keamanan",
        "Jalan",
        "Saluran Air",
        "Fasilitas Umum",
        "Lingkungan Lainnya"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Lapor / Pengaduan Lingkungan",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(24.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup")
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Aduan warga akan diteruskan langsung ke pengurus RT 08.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(14.dp))

                Text("Kategori Masalah:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                LazyColumn(
                    modifier = Modifier.height(110.dp)
                ) {
                    items(categories) { cat ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { category = cat }
                                .padding(vertical = 2.dp)
                        ) {
                            RadioButton(
                                selected = category == cat,
                                onClick = { category = cat }
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = cat, fontSize = 13.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Ringkasan Aduan") },
                    placeholder = { Text("Contoh: Lampu jalan tiang 3 padam") },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_report_title")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = locationDetail,
                    onValueChange = { locationDetail = it },
                    label = { Text("Lokasi Kejadian di RT 08") },
                    placeholder = { Text("Contoh: Jl. Giring Giring 1 No. 12") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Detail Masalah / Aduan") },
                    minLines = 3,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("input_report_desc")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Pelapor (Opsional)") },
                    placeholder = { Text("Warga RT 08") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("No. HP/WA (Opsional)") },
                    placeholder = { Text("0812...") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        if (title.isNotEmpty() && description.isNotEmpty()) {
                            onSubmit(name, phone, category, title, description, locationDetail)
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CivicGreenPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("btn_kirim_laporan")
                ) {
                    Text("Kirim Laporan Pengaduan")
                }
            }
        }
    }
}

// 6. REPORT DETAIL & STATUS UPDATE (FOR OFFICIALS)
@Composable
fun ReportDetailDialog(
    report: ReportEntity,
    isOfficial: Boolean,
    onDismiss: () -> Unit,
    onUpdateStatus: (ReportEntity, String, String) -> Unit
) {
    var selectedStatus by remember { mutableStateOf(report.status) }
    var responseNote by remember { mutableStateOf(report.responseNote) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CategoryChip(text = report.category)
                    StatusBadge(status = report.status)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = report.title,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = CivicGreenPrimary, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = report.locationDetail,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = report.description,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Pelapor: ${report.reporterName} • Waktu: ${Formatters.formatDateTime(report.createdAt)}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                if (report.responseNote.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = CivicGreenPrimary.copy(alpha = 0.08f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Tanggapan Pengurus RT:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CivicGreenPrimary)
                            Text(report.responseNote, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }

                if (isOfficial) {
                    Spacer(modifier = Modifier.height(16.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Tindak Lanjut Pengurus RT:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = CivicGreenPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Menunggu", "Diproses", "Selesai").forEach { st ->
                            Surface(
                                onClick = { selectedStatus = st },
                                color = if (selectedStatus == st) CivicGreenPrimary else MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    contentAlignment = Alignment.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                ) {
                                    Text(
                                        text = st,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selectedStatus == st) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = responseNote,
                        onValueChange = { responseNote = it },
                        label = { Text("Catatan Tindak Lanjut") },
                        placeholder = { Text("Contoh: Sudah diperbaiki / Petugas telah menangani") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { onUpdateStatus(report, selectedStatus, responseNote) },
                        colors = ButtonDefaults.buttonColors(containerColor = CivicGreenPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Perbarui Status Laporan")
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))
                TextButton(
                    onClick = onDismiss,
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Tutup")
                }
            }
        }
    }
}

// 7. SERVICES & LETTER REQUESTS DIALOG
@Composable
fun ServicesListDialog(
    letters: List<LetterRequestEntity>,
    onDismiss: () -> Unit,
    onOpenSubmitLetter: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Card(
            shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Surface(
                    color = CivicGreenPrimary,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Description, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Layanan Administrasi RT 08",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Button(
                            onClick = onOpenSubmitLetter,
                            colors = ButtonDefaults.buttonColors(containerColor = CivicGreenPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_ajukan_surat_pengantar")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Ajukan Permohonan Surat Pengantar RT")
                        }
                    }

                    item {
                        Text(
                            text = "Jenis Surat Pengantar yang Dilayani:",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        val services = listOf(
                            "Surat Pengantar Pembuatan KTP / KK" to "Syarat: Fotokopi KK lama, Akta Lahir/Buku Nikah",
                            "Surat Keterangan Domisili Tempat Tinggal" to "Syarat: KTP Asli dan surat bukti tinggal di RT 08",
                            "Surat Pengantar SKCK Polsek Sukmajaya" to "Syarat: Fotokopi KTP dan KK, pas foto 4x6",
                            "Surat Keterangan Belum Menikah" to "Syarat: Fotokopi KTP & KK, pernyataan belum menikah",
                            "Surat Keterangan Usaha (SKU) Mikro" to "Syarat: KTP, foto lokasi usaha di Jl. Giring Giring 1"
                        )
                        services.forEach { (srv, syarat) ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(text = srv, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(text = syarat, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Riwayat Pengajuan Surat Warga:",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    if (letters.isEmpty()) {
                        item {
                            Text(text = "Belum ada pengajuan surat.", fontSize = 12.sp, color = Color.Gray)
                        }
                    } else {
                        items(letters, key = { it.id }) { item ->
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(text = item.letterType, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                        StatusBadge(status = item.status)
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(text = "Pemohon: ${item.residentName} (${item.address})", fontSize = 12.sp)
                                    Text(text = "Keperluan: ${item.purpose}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 8. SUBMIT LETTER REQUEST FORM
@Composable
fun SubmitLetterDialog(
    onDismiss: () -> Unit,
    onSubmit: (name: String, nik: String, type: String, purpose: String, phone: String, address: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var nik by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("Pengantar KTP / KK") }
    var purpose by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("Jl. Giring Giring 1 No. ") }

    val letterTypes = listOf(
        "Pengantar KTP / KK",
        "Keterangan Domisili",
        "Pengantar SKCK Polsek",
        "Keterangan Belum Menikah",
        "Keterangan Usaha (SKU)"
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Permohonan Surat Pengantar RT",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Lengkap Pemohon") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = nik,
                    onValueChange = { nik = it },
                    label = { Text("NIK / No. Kartu Keluarga") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("Jenis Surat Pengantar:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                letterTypes.forEach { lt ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { type = lt }
                            .padding(vertical = 2.dp)
                    ) {
                        RadioButton(selected = type == lt, onClick = { type = lt })
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(lt, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = purpose,
                    onValueChange = { purpose = it },
                    label = { Text("Keperluan Penggunaan Surat") },
                    placeholder = { Text("Contoh: Mengurus perpanjangan KTP di Kelurahan Mekarjaya") },
                    minLines = 2,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("No. WhatsApp / HP Aktif") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Alamat Rumah di RT 08") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Batal") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isNotEmpty() && purpose.isNotEmpty()) {
                                onSubmit(name, nik, type, purpose, phone, address)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CivicGreenPrimary)
                    ) {
                        Text("Kirim Permohonan")
                    }
                }
            }
        }
    }
}

// 9. EMERGENCY & IMPORTANT CONTACTS DIALOG
@Composable
fun ContactListDialog(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val contacts = listOf(
        ContactItem("Ketua RT 08 (Pak Budi)", "08130798892", "Ketua RT 08 Jl. Giring Giring 1", Icons.Default.Person),
        ContactItem("Bendahara RT 08 (Bu Ika)", "087788141935", "Informasi Iuran & Kas RT", Icons.Default.Person),
        ContactItem("Sekretaris RT 08 (Paman Yani)", "08158223509", "Informasi Administrasi & Surat", Icons.Default.Person),
        ContactItem("Polisi", "110", "Panggilan Darurat Kepolisian", Icons.Default.Call),
        ContactItem("Pemadam Kebakaran", "112", "Layanan Darurat Damkar / Siaga 112", Icons.Default.Emergency),
        ContactItem("Pos Ronda & Keamanan RT 08", "082155550808", "Pos Ronda Jl. Giring Giring 1", Icons.Default.Emergency),
        ContactItem("Bhabinkamtibmas Mekarjaya", "081333330808", "Polsek Sukmajaya Depok", Icons.Default.Call),
        ContactItem("Babinsa Kelurahan Mekarjaya", "081244440808", "Koramil 03 Sukmajaya", Icons.Default.Call),
        ContactItem("Puskesmas Sukmajaya Depok", "02177829988", "Layanan Medis & UGD", Icons.Default.Emergency),
        ContactItem("Polsek Sukmajaya Depok", "02177820110", "Jl. Sentosa Raya Sukmajaya", Icons.Default.Call)
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Surface(
                    color = Color(0xFF059669),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Phone, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Kontak Penting & Darurat",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(contacts) { item ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = Color(0xFF059669).copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(imageVector = item.icon, contentDescription = null, tint = Color(0xFF059669), modifier = Modifier.size(20.dp))
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = item.name, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text(text = item.desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(text = item.number, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF059669))
                                }
                                IconButton(
                                    onClick = {
                                        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${item.number}"))
                                        context.startActivity(intent)
                                    }
                                ) {
                                    Icon(imageVector = Icons.Default.Call, contentDescription = "Panggil", tint = Color(0xFF059669))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class ContactItem(
    val name: String,
    val number: String,
    val desc: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

// 10. OFFICIALS STRUCTURE DIALOG
@Composable
fun OfficialsListDialog(onDismiss: () -> Unit) {
    val officials = listOf(
        OfficialPerson("Rehan Ardiyanto", "Admin", "Jl. Giring Giring 1"),
        OfficialPerson("M. Budi Prasetyo", "Ketua RT", "Jl. Giring Giring 1 No. 5"),
        OfficialPerson("Ika", "Bendahara", "Jl. Giring Giring 1 No. 11"),
        OfficialPerson("Ahmad Yani", "Sekretaris", "Jl. Giring Giring 1 No. 8"),
        OfficialPerson("Sugeng Priyadi", "Wakil Ketua RT 08", "Jl. Giring Giring 1 No. 17"),
        OfficialPerson("Joko Santoso", "Seksi Keamanan & Ronda", "Jl. Giring Giring 1 No. 2"),
        OfficialPerson("Agus Prasetyo", "Seksi Kebersihan & Lingkungan", "Jl. Giring Giring 1 No. 14"),
        OfficialPerson("Ir. Gunawan Wibowo", "Seksi Pembangunan Sarana", "Jl. Giring Giring 1 No. 30"),
        OfficialPerson("Ibu Sri Wahyuni", "Koordinator Posyandu & PKK RT", "Jl. Giring Giring 1 No. 9")
    )

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                Surface(
                    color = Color(0xFF4F46E5),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Groups, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Pengurus RT 08 / RW 10",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(officials) { person ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    color = Color(0xFF4F46E5).copy(alpha = 0.15f),
                                    shape = CircleShape,
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = person.name.take(1),
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF4F46E5)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(text = person.name, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    Text(text = person.position, fontSize = 12.sp, color = Color(0xFF4F46E5), fontWeight = FontWeight.Medium)
                                    Text(text = person.address, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private data class OfficialPerson(val name: String, val position: String, val address: String)

// 11. ABOUT RT DIALOG
@Composable
fun AboutRtDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                Surface(
                    color = Color(0xFF7C3AED),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Info, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Tentang RT 08 SMART",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        IconButton(onClick = onDismiss) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Tutup", tint = Color.White)
                        }
                    }
                }

                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "RT 08 / RW 10 – Jl. Giring Giring 1",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Kelurahan Mekarjaya, Kecamatan Sukmajaya, Kota Depok, Jawa Barat",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Profil Lingkungan",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF7C3AED)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Lingkungan RT 08 berlokasi di sepanjang Jl. Giring Giring 1, Kelurahan Mekarjaya, Sukmajaya, Kota Depok. Terdiri dari kurang lebih 68 Kepala Keluarga (KK) yang guyub, aktif dalam kegiatan gotong royong, pos ronda keamanan, pemilahan sampah, dan kegiatan sosial kemasyarakatan.",
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Visi RT 08 SMART",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF7C3AED)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "\"Mewujudkan lingkungan rukun tetangga yang Sejahtera, Mandiri, Aman, Rukun, dan Transparan (SMART) berbasis gotong royong dan kemudahan digital.\"",
                        fontSize = 13.sp,
                        lineHeight = 19.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Misi Kepengurusan",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF7C3AED)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "1. Transparansi arus kas dan iuran warga secara akuntabel dan terbuka.\n2. Peningkatan sistem keamanan lingkungan melalui portal dan ronda warga.\n3. Kebersihan saluran air, drainase, dan tata kelola sampah lingkungan.\n4. Pelayanan surat pengantar administrasi kependudukan yang cepat dan ramah.",
                        fontSize = 12.sp,
                        lineHeight = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Tutup Informasi")
                    }
                }
            }
        }
    }
}

// 12. ADD USER DIALOG (ADMIN UTAMA)
@Composable
fun AddUserDialog(
    onDismiss: () -> Unit,
    onSubmit: (name: String, username: String, passwordRaw: String, position: String, role: UserRole) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var position by remember { mutableStateOf("") }
    var selectedRole by remember { mutableStateOf(UserRole.SEKRETARIS) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "Buat Akun Pengurus Baru",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nama Pengurus") },
                    placeholder = { Text("Contoh: Ahmad Fauzi") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = username,
                    onValueChange = { username = it.lowercase().filter { char -> char.isLetterOrDigit() } },
                    label = { Text("Username") },
                    placeholder = { Text("Contoh: fauzi88") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password Awal") },
                    placeholder = { Text("Minimal 6 karakter") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = position,
                    onValueChange = { position = it },
                    label = { Text("Jabatan di RT 08") },
                    placeholder = { Text("Contoh: Sie Keamanan / Humas") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("Hak Akses / Role:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                listOf(UserRole.ADMIN_UTAMA, UserRole.KETUA_RT, UserRole.BENDAHARA, UserRole.SEKRETARIS).forEach { role ->
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedRole = role }
                            .padding(vertical = 2.dp)
                    ) {
                        RadioButton(selected = selectedRole == role, onClick = { selectedRole = role })
                        Spacer(modifier = Modifier.width(4.dp))
                        val roleDesc = when (role) {
                            UserRole.ADMIN_UTAMA -> "Akses Penuh Admin"
                            UserRole.KETUA_RT -> "Pimpinan RT & Akses Penuh"
                            UserRole.BENDAHARA -> "Kelola Kas & Transaksi"
                            UserRole.SEKRETARIS -> "Pengumuman, Agenda & Surat"
                            else -> ""
                        }
                        Text("${role.label} ($roleDesc)", fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Batal") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isNotEmpty() && username.isNotEmpty() && password.isNotEmpty()) {
                                onSubmit(name, username, password, position, selectedRole)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CivicGreenPrimary)
                    ) {
                        Text("Simpan Akun")
                    }
                }
            }
        }
    }
}

// 13. RESET PASSWORD DIALOG (ADMIN UTAMA)
@Composable
fun ResetPasswordDialog(
    user: UserEntity,
    onDismiss: () -> Unit,
    onSubmit: (newPasswordRaw: String) -> Unit
) {
    var newPassword by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reset Password @${user.username}") },
        text = {
            Column {
                Text("Masukkan password baru untuk akun ${user.name} (${user.position}):", fontSize = 13.sp)
                Spacer(modifier = Modifier.height(10.dp))
                OutlinedTextField(
                    value = newPassword,
                    onValueChange = { newPassword = it },
                    label = { Text("Password Baru") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (newPassword.isNotEmpty()) {
                        onSubmit(newPassword)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CivicGreenPrimary)
            ) {
                Text("Simpan Password")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Batal") }
        }
    )
}
