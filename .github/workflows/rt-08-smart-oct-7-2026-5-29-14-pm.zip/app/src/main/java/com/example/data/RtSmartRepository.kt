package com.example.data

import com.example.data.model.AgendaEntity
import com.example.data.model.AnnouncementEntity
import com.example.data.model.AuditLogEntity
import com.example.data.model.LetterRequestEntity
import com.example.data.model.ReportEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.UserEntity
import kotlinx.coroutines.flow.Flow

class RtSmartRepository(private val dao: RtSmartDao) {

    // Users
    val allUsers: Flow<List<UserEntity>> = dao.getAllUsers()
    suspend fun getUserByUsername(username: String): UserEntity? = dao.getUserByUsername(username)
    suspend fun insertUser(user: UserEntity): Long = dao.insertUser(user)
    suspend fun updateUser(user: UserEntity) = dao.updateUser(user)
    suspend fun deleteUser(user: UserEntity) = dao.deleteUser(user)
    suspend fun getUserCount(): Int = dao.getUserCount()

    // Transactions
    val allTransactions: Flow<List<TransactionEntity>> = dao.getAllTransactions()
    val publicTransactions: Flow<List<TransactionEntity>> = dao.getPublicTransactions()
    suspend fun insertTransaction(transaction: TransactionEntity): Long = dao.insertTransaction(transaction)
    suspend fun updateTransaction(transaction: TransactionEntity) = dao.updateTransaction(transaction)
    suspend fun deleteTransaction(transaction: TransactionEntity) = dao.deleteTransaction(transaction)

    // Announcements
    val allAnnouncements: Flow<List<AnnouncementEntity>> = dao.getAllAnnouncements()
    suspend fun insertAnnouncement(announcement: AnnouncementEntity): Long = dao.insertAnnouncement(announcement)
    suspend fun updateAnnouncement(announcement: AnnouncementEntity) = dao.updateAnnouncement(announcement)
    suspend fun deleteAnnouncement(announcement: AnnouncementEntity) = dao.deleteAnnouncement(announcement)

    // Agendas
    val allAgendas: Flow<List<AgendaEntity>> = dao.getAllAgendas()
    suspend fun insertAgenda(agenda: AgendaEntity): Long = dao.insertAgenda(agenda)
    suspend fun updateAgenda(agenda: AgendaEntity) = dao.updateAgenda(agenda)
    suspend fun deleteAgenda(agenda: AgendaEntity) = dao.deleteAgenda(agenda)

    // Reports
    val allReports: Flow<List<ReportEntity>> = dao.getAllReports()
    suspend fun insertReport(report: ReportEntity): Long = dao.insertReport(report)
    suspend fun updateReport(report: ReportEntity) = dao.updateReport(report)
    suspend fun deleteReport(report: ReportEntity) = dao.deleteReport(report)

    // Letter Requests
    val allLetterRequests: Flow<List<LetterRequestEntity>> = dao.getAllLetterRequests()
    suspend fun insertLetterRequest(request: LetterRequestEntity): Long = dao.insertLetterRequest(request)
    suspend fun updateLetterRequest(request: LetterRequestEntity) = dao.updateLetterRequest(request)

    // Audit Logs
    val allAuditLogs: Flow<List<AuditLogEntity>> = dao.getAllAuditLogs()
    suspend fun insertAuditLog(log: AuditLogEntity): Long = dao.insertAuditLog(log)

    suspend fun ensureDataSeeded() {
        AppDatabase.seedInitialData(dao)
    }
}
